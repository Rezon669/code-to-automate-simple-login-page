package com.selenium1.testscript;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Keywords {
	static ChromeDriver d;
	static FileInputStream file;
	static Properties prop;


public void Openbrowser() throws IOException {
	System.setProperty("webdriver.chrome.driver","C:\\Users\\Rezon\\Downloads\\chromedriver_win32\\chromedriver.exe");
	 d = new ChromeDriver();	
	d.manage().timeouts().implicitlyWait(1,TimeUnit.MINUTES);
	d.manage().window().maximize();
	 file = new FileInputStream("C:\\Users\\Rezon\\eclipse-workspace\\Selenium1\\src\\test\\java\\com\\selenium1\\objectrepository\\Fields.properties");
	prop = new Properties();
	prop.load(file);
	}

public void Navigate(String data) throws InterruptedException {
	d.get(data);
	Thread.sleep(1000);
}
public void Input(String Objectname, CharSequence Data) throws InterruptedException {
	d.findElementByXPath(prop.getProperty(Objectname)).sendKeys(Data);
	Thread.sleep(1000);
}
public void Click(String Objectname) {
	// TODO Auto-generated method stub
	d.findElementByXPath(prop.getProperty(Objectname)).click();
	

}
}

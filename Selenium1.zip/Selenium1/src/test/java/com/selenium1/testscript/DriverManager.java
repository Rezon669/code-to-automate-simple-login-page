package com.selenium1.testscript;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook; 
public class DriverManager extends Keywords  {
 
public static  void main(String args[]) throws IOException, InterruptedException {
Keywords key = new Keywords();
ArrayList data = new ArrayList();  
FileInputStream fis=new FileInputStream("C:\\Users\\Rezon\\OneDrive\\Documents\\Project.xlsx");  
 

XSSFWorkbook wb = new XSSFWorkbook(fis);   
XSSFSheet s = wb.getSheetAt(0);
Iterator itr = s.iterator();
while(itr.hasNext()) {
Row row =	(Row) itr.next();
Iterator cellitr = row.cellIterator();
while(cellitr.hasNext()) {
Cell celldata =	(Cell) cellitr.next();
switch(celldata.getCellType()) {
case Cell.CELL_TYPE_STRING:
	//System.out.println(celldata.getStringCellValue());
data.add(celldata.getStringCellValue());
	break;
case Cell.CELL_TYPE_NUMERIC:
	//System.out.println(celldata.getNumericCellValue());
	data.add(celldata.getNumericCellValue());
	break;
case Cell.CELL_TYPE_BOOLEAN:
	data.add(celldata.getBooleanCellValue());
	break;
}
}
}
for(int i=0; i<data.size(); i++) {
	if(data.get(i).equals("Openbrowser")) {
		String Keyword = (String) data.get(i);
		String Data = (String) data.get(i+1);
		String Objectname = (String) data.get(i+2);
		String Runmode = (String) data.get(i+3);
		System.out.println(Keyword);
		System.out.println(Data);
		System.out.println(Objectname);
		System.out.println(Runmode);
		if(Runmode.equals("yes")) {
			key.Openbrowser();
		}
		}
	if(data.get(i).equals("Navigate")) {
			String Keyword = (String) data.get(i);
			String Data = (String) data.get(i+1);
			String Objectname = (String) data.get(i+2);
			String Runmode = (String) data.get(i+3);
			System.out.println(Keyword);
			System.out.println(Data);
			System.out.println(Objectname);
			System.out.println(Runmode);
			if(Runmode.equals("yes")) {
				key.Navigate(Data);
			}
			}
	
	if(data.get(i).equals("Input")) {
				String Keyword = (String) data.get(i);
				String Data = (String) data.get(i+1);
				String Objectname = (String) data.get(i+2);
				String Runmode = (String) data.get(i+3);
				System.out.println(Keyword);
				System.out.println(Data);
			System.out.println(Objectname);
				System.out.println(Runmode);
				if(Runmode.equals("yes")) {
					key.Input(Objectname, Data);
				}
				}
	
	if(data.get(i).equals("Click")) {
		String Keyword = (String) data.get(i);
		String Data = (String) data.get(i+1);
		String Objectname = (String) data.get(i+2);
		String Runmode = (String) data.get(i+3);
		System.out.println(Keyword);
		System.out.println(Data);
		System.out.println(Objectname);
		System.out.println(Runmode);
		if(Runmode.equals("yes")) {
			key.Click(Objectname);
		}
		}
	
	}
}}

